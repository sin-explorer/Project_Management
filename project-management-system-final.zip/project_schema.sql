
CREATE TABLE Project (
    id INT PRIMARY KEY AUTO_INCREMENT,
    projectName VARCHAR(100),
    description TEXT,
    startDate DATE,
    status VARCHAR(50)
);

CREATE TABLE Employee (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    designation VARCHAR(50),
    gender VARCHAR(10),
    salary DOUBLE,
    project_id INT,
    FOREIGN KEY (project_id) REFERENCES Project(id)
);

CREATE TABLE Task (
    task_id INT PRIMARY KEY AUTO_INCREMENT,
    task_name VARCHAR(100),
    project_id INT,
    employee_id INT,
    status VARCHAR(50),
    allocation_date DATE,
    deadline_date DATE,
    FOREIGN KEY (project_id) REFERENCES Project(id),
    FOREIGN KEY (employee_id) REFERENCES Employee(id)
);
