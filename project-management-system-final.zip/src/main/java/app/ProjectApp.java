
package app;

public class ProjectApp {
    public static void main(String[] args) {
        System.out.println("Welcome to the Project Management System!");
        // You can start your service/controller here
    }
}
