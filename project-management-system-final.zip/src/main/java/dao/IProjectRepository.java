
package dao;

import entity.Employee;
import entity.Project;
import entity.Task;

import java.util.List;

public interface IProjectRepository {
    void addProject(Project project);
    void addEmployee(Employee employee);
    void assignTask(Task task);
    List<Employee> getEmployeesByProjectId(int projectId);
    List<Task> getTasksByEmployeeId(int employeeId);
}
