
package dao;

import entity.Employee;
import entity.Project;
import entity.Task;
import util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProjectRepositoryImpl implements IProjectRepository {

    private Connection conn = DBConnUtil.getConnection();

    @Override
    public void addProject(Project project) {
        try {
            String sql = "INSERT INTO Project (projectName, description, startDate, status) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, project.getProjectName());
            ps.setString(2, project.getDescription());
            ps.setDate(3, Date.valueOf(project.getStartDate()));
            ps.setString(4, project.getStatus());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void addEmployee(Employee employee) {
        try {
            String sql = "INSERT INTO Employee (name, designation, gender, salary, project_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, employee.getName());
            ps.setString(2, employee.getDesignation());
            ps.setString(3, employee.getGender());
            ps.setDouble(4, employee.getSalary());
            ps.setInt(5, employee.getProjectId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void assignTask(Task task) {
        try {
            String sql = "INSERT INTO Task (task_name, project_id, employee_id, status, allocation_date, deadline_date) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, task.getTaskName());
            ps.setInt(2, task.getProjectId());
            ps.setInt(3, task.getEmployeeId());
            ps.setString(4, task.getStatus());
            ps.setDate(5, Date.valueOf(task.getAllocationDate()));
            ps.setDate(6, Date.valueOf(task.getDeadlineDate()));
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Employee> getEmployeesByProjectId(int projectId) {
        List<Employee> employees = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Employee WHERE project_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, projectId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Employee e = new Employee(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("designation"),
                    rs.getString("gender"),
                    rs.getDouble("salary"),
                    rs.getInt("project_id")
                );
                employees.add(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }

    @Override
    public List<Task> getTasksByEmployeeId(int employeeId) {
        List<Task> tasks = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Task WHERE employee_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Task t = new Task(
                    rs.getInt("task_id"),
                    rs.getString("task_name"),
                    rs.getInt("project_id"),
                    rs.getInt("employee_id"),
                    rs.getString("status"),
                    rs.getDate("allocation_date").toLocalDate(),
                    rs.getDate("deadline_date").toLocalDate()
                );
                tasks.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tasks;
    }
}
