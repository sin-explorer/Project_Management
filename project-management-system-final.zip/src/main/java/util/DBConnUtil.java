
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.io.InputStream;

public class DBConnUtil {
    private static Connection connection;

    public static Connection getConnection() {
        try {
            Properties props = new Properties();
            InputStream input = DBConnUtil.class.getClassLoader().getResourceAsStream("db.properties");
            props.load(input);

            String host = props.getProperty("host");
            String port = props.getProperty("port");
            String dbname = props.getProperty("dbname");
            String username = props.getProperty("username");
            String password = props.getProperty("password");

            String url = "jdbc:mysql://" + host + ":" + port + "/" + dbname;

            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(url, username, password);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }
}
