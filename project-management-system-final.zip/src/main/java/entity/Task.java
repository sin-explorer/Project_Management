
package entity;

import java.time.LocalDate;

public class Task {
    private int taskId;
    private String taskName;
    private int projectId;
    private int employeeId;
    private String status;
    private LocalDate allocationDate;
    private LocalDate deadlineDate;

    public Task(int taskId, String taskName, int projectId, int employeeId, String status, LocalDate allocationDate, LocalDate deadlineDate) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.projectId = projectId;
        this.employeeId = employeeId;
        this.status = status;
        this.allocationDate = allocationDate;
        this.deadlineDate = deadlineDate;
    }

    // Getters and Setters
}
