
package entity;

public class Employee {
    private int id;
    private String name;
    private String designation;
    private String gender;
    private double salary;
    private int projectId;

    public Employee(int id, String name, String designation, String gender, double salary, int projectId) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        this.gender = gender;
        this.salary = salary;
        this.projectId = projectId;
    }

    // Getters and Setters
}
