
package entity;

import java.time.LocalDate;

public class Project {
    private int id;
    private String projectName;
    private String description;
    private LocalDate startDate;
    private String status;

    public Project(int id, String projectName, String description, LocalDate startDate, String status) {
        this.id = id;
        this.projectName = projectName;
        this.description = description;
        this.startDate = startDate;
        this.status = status;
    }

    // Getters and Setters
}
